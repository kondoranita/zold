<?php

class Irestful_Model
{
	public function get_data($vars)
    {
		
	}
	
}

?>


