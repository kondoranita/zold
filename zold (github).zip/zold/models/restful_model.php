<?php

class Restful_Model
{
	public function get_data($vars)
    {
		
	}
	
}

?>


