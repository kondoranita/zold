<?php
class grafikon_Model {

  public function grafikon(){
    //-------------------------------------------------------------------------
    //- Grafikon                                                              -
    //-------------------------------------------------------------------------
    //if(isset($_POST['grafi'])) {
    
    //echo "Grafikon button is pressed, i'm here on the pdf_model!";
    
    try {
            $connection = Database::getConnection();
            $sql_lekerdezes2 = "SELECT szolgid, 
                                SUM(mennyiseg) AS mennyiseg, tipus, jelentes
                                FROM lakig
                                JOIN szolgaltatas
                                ON id = szolgid 
                                Group By szolgid";
            
            $sth_lekerdezes2 = $connection->prepare($sql_lekerdezes2);
            $sth_lekerdezes2->execute(array());
            $eredmeny['lekerdezes2'] = $sth_lekerdezes2->fetchAll(PDO::FETCH_ASSOC);
            $_SESSION['lekerdezes2'] = $eredmeny['lekerdezes2'];
            $lekerdezes2 = $eredmeny['lekerdezes2'];
            
            $y = count($lekerdezes2)-1;
            
            for($x=0; $x<=$y; $x++) {
                //echo $lekerdezes2[$x]['szolgid']."<br>";
                $le_szolgid[$x] = $lekerdezes2[$x]['szolgid'];
            }
            for($x=0; $x<=$y; $x++) {
                //echo $lekerdezes2[$x]['mennyiseg']."<br>";
                $le_menny[$x] = $lekerdezes2[$x]['mennyiseg'];
            }
            for($x=0; $x<=$y; $x++) {
                //echo $lekerdezes2[$x]['mennyiseg']."<br>";
                $le_tipus[$x] = $lekerdezes2[$x]['tipus'];
            }
            for($x=0; $x<=$y; $x++) {
                //echo $lekerdezes2[$x]['mennyiseg']."<br>";
                $le_jelentes[$x] = $lekerdezes2[$x]['jelentes'];
            }
            
            $_SESSION['labels'] = $le_szolgid;
            $_SESSION['labels2'] = $le_tipus;
            $_SESSION['labels3'] = $le_jelentes;
            $_SESSION['adatok1'] = $le_menny;
           // $_SESSION['title1'] = $grafikon['tipus'];
           // $_SESSION['title2'] = $grafikon['tipus'];
            
            
            
            
            
            }
    	catch (PDOException $e) {
            $graf["hibakod"] = 1;
            $graf["uzenet"] = $e->getMessage();
    	}
        
        
        


try {
            $connection = Database::getConnection();
            $sql_lekerdezes2 = "SELECT igeny, mennyiseg, tipus, jelentes
                                FROM lakig
                                JOIN szolgaltatas
                                ON id = szolgid 
                                ORDER BY igeny";
            
            $sth_lekerdezes2 = $connection->prepare($sql_lekerdezes2);
            $sth_lekerdezes2->execute(array());
            $eredmeny['lekerdezes2'] = $sth_lekerdezes2->fetchAll(PDO::FETCH_ASSOC);
            $_SESSION['lekerdezes2'] = $eredmeny['lekerdezes2'];
            $lekerdezes2 = $eredmeny['lekerdezes2'];
            
            $y = count($lekerdezes2)-1;
            
            for($x=0; $x<=$y; $x++) {
                //echo $lekerdezes2[$x]['szolgid']."<br>";
                $le_igeny2[$x] = $lekerdezes2[$x]['igeny'];
            }
            for($x=0; $x<=$y; $x++) {
                //echo $lekerdezes2[$x]['mennyiseg']."<br>";
                $le_menny2[$x] = $lekerdezes2[$x]['mennyiseg'];
            }
            for($x=0; $x<=$y; $x++) {
                //echo $lekerdezes2[$x]['mennyiseg']."<br>";
                $le_tipus2[$x] = $lekerdezes2[$x]['tipus'];
            }
            for($x=0; $x<=$y; $x++) {
                //echo $lekerdezes2[$x]['mennyiseg']."<br>";
                $le_jelentes2[$x] = $lekerdezes2[$x]['jelentes'];
            }
            
            $_SESSION['lab1'] = $le_igeny2;
            $_SESSION['lab2'] = $le_tipus2;
            $_SESSION['lab3'] = $le_jelentes2;
            $_SESSION['adatok2'] = $le_menny2;
           // $_SESSION['title1'] = $grafikon['tipus'];
           // $_SESSION['title2'] = $grafikon['tipus'];
            
            
            
            
            
            }
    	catch (PDOException $e) {
            $graf["hibakod"] = 1;
            $graf["uzenet"] = $e->getMessage();
    	}
        
}
}
//}