<?php







    try {
            $connection = Database::getConnection();
            $sql_graf = "SELECT * 
                              FROM lakig
                              JOIN szolgaltatas
                              ON szolgaltatas.id = szolgid
                              ORDER BY igeny ASC";
            
            $sth_graf = $connection->prepare($sth_graf);
            $sth_graf->execute(array());
            $graf['lekerdezes'] = $sth_graf->fetchAll(PDO::FETCH_ASSOC);
            $_SESSION['lekerdezes'] = $graf['lekerdezes'];
            $grafikon = $graf['lekerdezes'];
            
            
            }
    	catch (PDOException $e) {
            $graf["hibakod"] = 1;
            $graf["uzenet"] = $e->getMessage();
    	}

?>

$adatok1 = $grafikon['igeny'];
$adatok1 = $grafikon['mennyiseg'];
$title1 = "D�tum";
$title2 = "Mennyis�g";


<script>	//-------- diagramm --------

const ctx = document.getElementById('myChart');
const myChart = new Chart(ctx, {
    type: 'line',
    data: {
       datasets: [{
           label: <?php echo json_encode($title1); ?>,
           data: <?php echo json_encode($adatok1); ?>,
           borderColor: 'rgb(255,28,37)',
           borderWidth: 4,
           order: 2
       }, {
           label: <?php echo json_encode($title2); ?>,
           data: <?php echo json_encode($adatok2); ?>,
           type: 'line',
           borderColor: 'rgb(0,111,255)',
           borderWidth: 4,
           order: 1
           
       }],
       
       labels: <?php echo json_encode($labels); ?>
   },
    options: {
        scales: {
            y: {
                beginAtZero: false
            }
        }
    }
});
</script>
