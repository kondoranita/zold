<head>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body {
    background-image: url('images/charts.jpg');
    background-size: 100% 100%;
}
</style>
</head>
<body>





<?php
if(isset($_SESSION['adatok1'])) {


$labels = $_SESSION['labels2'];
$labels3 = $_SESSION['labels3'];
$adatok1 = $_SESSION['adatok1'];
$title1 = "Kirakott hulladék mennyisége - 2018";
$title2 = "Kirakott hulladék mennyisége idő szerint";

$lab1 = $_SESSION['lab1'];
$adatok2 = $_SESSION['adatok2'];

?>

<div>
    <canvas id="layanan" width="240px" height="240px"></canvas>
    <p>mua: <?php echo $labels3[0]; ?></p> 
    <p>zold: <?php echo $labels3[1]; ?></p> 
    <p>pa: <?php echo $labels3[2]; ?></p> 
    <p>kom: <?php echo $labels3[3]; ?></p> 
</div>



<div>
    <canvas id="layanan_subbagian" width="540px" height="240px"></canvas>
</div>




<script>
        $(function () {
            var ctx = document.getElementById("layanan").getContext('2d');
            var data = {
                datasets: [{
                    label: <?php echo json_encode($title1); ?>,
                    data: <?php echo json_encode($adatok1); ?>,
                    backgroundColor: [
                        '#3c8dbc',
                        '#007200',
                        '#9A5E29',
                        '#f39c12',
                    ],
                }],
                labels: <?php echo json_encode($labels); ?>
                
            };
            var myDoughnutChart = new Chart(ctx, {
                type: 'bar',
                data: data,
                options: {
                    responsive: false,
                    maintainAspectRatio: false,
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12
                        }
                    }
                }
            });
            
//----------------------------------------------------------------------------------------------------------
//
//----------------------------------------------------------------------------------------------------------


            var ctx_2 = document.getElementById("layanan_subbagian").getContext('2d');
            var data_2 = {
                datasets: [{
                    label: <?php echo json_encode($title2); ?>,
                    data: <?php echo json_encode($adatok2); ?>,
                    
                }],
                labels: <?php echo json_encode($lab1); ?>
            };
            var myDoughnutChart_2 = new Chart(ctx_2, {
                type: 'line',
                data: data_2,
                options: {
                    responsive: false,
                    maintainAspectRatio: false,
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12
                        }
                    }
                }
            });
        });

    </script>




</body>

<?php
unset($_SESSION['adatok1']);
}