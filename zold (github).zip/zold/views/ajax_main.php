<!DOCTYPE HTML>
<html>
  <head>
  <meta charset="utf-8">
  <script type="text/javascript" src = "java/jquery.min.js"></script>
  <script type="text/javascript" src = "java/ajax.js"></script>
  <title>Hulladékszállítás</title>
  <style>
    #informaciosdiv {
      width: 1600px;
    }
    #intezmenyinfo {
      float: right;
      border: 5px solid green;
      width: 1000px;
      height: 300px;
    }
    .cimke{
      display: inline-block;
      width: 270px;
      text-align: left;
    }
    span {
      margin: 5px 6px;<br><br>
    }
    label {
      display: inline-block;
      width: 300px;
      text-align: left;
    }
    select {
      width: 215px;
    }
  </style>
  </head>
  <body class="ajax_background">
  <body>
    <h1>Hulladékszállítási információk:</h1>
    <div id = 'informaciosdiv'>
      <div id = 'intezmenyinfo'>
        <span class="cimke">Hulladéktípusa:</span><span id="nev" class="adat"></span><br>
		<br>
	    <br>
        <span class="cimke">Szolgáltatás időpontja:</span><span id="cim" class="adat"></span><br>
        <br>
	    <br>
	    <span class="cimke">Hulladék kirakás/szállítási igény napja:</span><span id="tel" class="adat"></span><br>
        <br>
	    <br>
		<span class="cimke">Mennyiség:</span><span id="mail" class="adat"></span><br>
      </div>
      <label for='orszagcimke'>Típus:</label>
      <select id = 'orszagselect'></select>
      <br><br>
      <label for = 'varoscimke'>Hulladékszállítás napja:</label>
      <select id = 'varosselect'></select>
      <br><br>
      <label for = 'varoscimke'>Hulladék kirakásának napja:</label>
      <select id = 'intezmenyselect'></select>
    </div>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	
  </body>

</html>
