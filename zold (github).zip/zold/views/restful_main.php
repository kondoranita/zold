<?php
$url = "http://localhost/zold/restfulserv/szerver.php";
$result = "";
if(isset($_POST['id']))
{
  // Felesleges szóközök eldobása
  $_POST['id'] = trim($_POST['id']);
  $_POST['tip'] = trim($_POST['tip']);
  $_POST['jel'] = trim($_POST['jel']);

  
  // Ha nincs id és megadtak minden adatot (tipus, jelentés), akkor beszúrás
  if($_POST['id'] == "" && $_POST['tip'] != "" && $_POST['jel'] != "")
  {
      $data = Array("tip" => $_POST["tip"], "jel" => $_POST["jel"]);
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);
  }
  
  // Ha nincs id de nem adtak meg minden adatot
  elseif($_POST['id'] == "")
  {
    $result = "Hiba: Hiányos adatok!";
  }
  
  // Ha van id, amely >= 1, és megadták legalább az egyik adatot (tipus, jelentés), akkor módosítás
  elseif($_POST['id'] >= 1 && ($_POST['tip'] != "" || $_POST['jel'] != ""))
  {
      $data = Array("id" => $_POST["id"], "tip" => $_POST["tip"], "jel" => $_POST["jel"]);
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);
  }
  
  // Ha van id, amely >=1, de nem adtak meg legalább az egyik adatot
  elseif($_POST['id'] >= 1)
  {
      $data = Array("id" => $_POST["id"]);
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $result = curl_exec($ch);
      curl_close($ch);
  }
  
  // Ha van id, de rossz az id, akkor a hiba kiírása
  else
  {
    echo "Hiba: Rossz azonosító (Id): ".$_POST['id']."<br>";
  }
}

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$tabla = curl_exec($ch);
curl_close($ch);

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>RESTFUL</title>
</head>
<body class="restful_background">
    <?= $result ?>
    <h1>Szolgáltatások:</h1>
    <?= $tabla ?>
    <br>
    <h2>Módosítás / Beszúrás / Törlés</h2>
    <form method="post">
    Id: <input type="text" name="id"><br><br>
    Tipus <input type="text" name="tip" maxlength="45"> <br><br>
    Jelentés: <input type="text" name="jel" maxlength="100"> <br><br>
    <input type="submit" value = "Küldés">
    </form>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>	
<br><br>
<br><br>
</body>
</html>
