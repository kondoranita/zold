<body class="nyit_background"></body>
 <div class="kulso">
 <div class="belso">
	    
				
				<div class="cim">
				<h1></b></h1></div>
				<div class="szöveg">
				<p> 
				
				
				
				<h1>
				RÓLUNK <br><br>
				A hulladékokról szóló törvény szerint a hulladék bármely anyag vagy tárgy, amelytől birtokosa megválik, megválni szándékozik vagy megválni köteles. Ez a fogalom azonban egy sor, igen összetett feladatot is hordoz magával. A hulladékokról gondoskodni kell és ez nem egy lehetőség, hanem mindnyájunk kötelessége, amennyiben a jövő generációja számára is szeretnénk fenntartani egy élhető környezetet, világot.
                A Zöldbolygó Közszolgáltató Nonprofit Kft. 1995.-ben alakult és kezdte meg tevékenykedését egyrészt, mint térségi hulladékgazdálkodó, másrészt olyan szolgáltatásokat ellátó cég, amely a közösség érdekeit képviselik. Tisztában vagyunk azzal, hogy szolgáltatásainkkal számos területen nagy hatást gyakorlunk az érintett lakosságra, valamint a minket közvetlenül és közvetve körülvevő igen sérülékeny környezetre. Jelenleg 25 településen látunk el hulladékszállítási feladatokat közel 200.000 ügyfelet kiszolgálva ezzel.<br><br>
                Célunk, hogy a minőségi, rugalmas, adott település helyi igényeinek megfelelő szolgáltatás mellett a környezetterhelést minimálisra csökkentsük úgy, hogy közben a vállalat működése a jelenlegi jogszabályi háttérnek maximálisan megfeleljen. Környezetünk védelme és annak megóvása közös cél. Hiszünk abban, hogy ennek egyik alapvető eleme a hulladékok megfelelő kezelése, a szelektív hulladékgyűjtés és az újrahasznosítás.<br><br>
                A települési szilárd hulladékok gyűjtése mellett nagy tapasztalattal rendelkezünk a szelektív hulladékgyűjtés területén is. Boncida városában 1995 óta működik szelektív hulladékgyűjtő szigetes hulladékgyűjtés a társasházas övezetekben, 2008-tól pedig a települési hulladékkal kapcsolatos közszolgáltatás részeként bevezetésre került a házhoz menő szelektív hulladékgyűjtés is. A projekt során egyrészt a házhoz menő szelektív hulladékgyűjtési rendszer fejlesztése és ahol még nem működött annak kiépítése történt meg, valamint a települési szilárd hulladék hatékonyabb kezeléséhez szükséges eszközök is beszerzésre kerültek.<br><br>
                A fentieknek köszönhetően elmondhatjuk, hogy a szolgáltatásainkkal érintett területek majdnem mindegyikén működik a házhoz menő szelektív hulladékgyűjtés, amely már 120 literes műanyag hulladékgyűjtő edényekkel valósul meg. Továbbá társaságunk igazán nagy hangsúlyt fektet a gyermekek környezettudatos nevelésére is. Büszkén mondhatjuk, hogy közel 1500 gyermek kirándult a Boncidai Regionális Hulladékkezelő Központ tanösvényén, illetve vett részt telephely látogatáson.<br><br><h1>
				A Zöldbolygó Kft-t azért hoztuk létre, hogy a környezeti fenntarthatóság érdekében partnerei lehessünk minden, közös jövőnkért tenni akaró, felelős embernek.<br><br>
				Legyen Ön is a szövetségesünk!<br><br>
				Szövetségesünk a megelőzésben, a szemléletváltásban, mások meggyőzésében.<br><br>
	 				
</div>