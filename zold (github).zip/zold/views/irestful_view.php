<?php

function create_table($array, $table = true)
{
    $out = '';
    foreach ($array as $key => $value) {
        if (is_array($value)) {
            if (!isset($tableHeader)) {
                $tableHeader =
                    '<th>' .
                    implode('</th><th>', array_keys($value)) .
                    '</th>';
            }
            array_keys($value);
            $out .= '<tr>';
            $out .= create_table($value, false);
            $out .= '</tr>';
        } else {
            $out .= "<td> $value </td>";
        }
    }

    if ($table) {
        echo '<div class="tabla"><table>' . $tableHeader . $out . '</table></div>';
    } else {
        return $out;
    }
}

function get_rest()
{
	$url = "https://gorest.co.in/public/v1/users?access-token=a217ccb49c3be7355cc0c0c12ad4d2e6f915c23094b2e67ed30ed8c092e745de";
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$tabla = curl_exec($ch);
	curl_close($ch);
	$_POST['tabla'] = json_decode($tabla, JSON_PRETTY_PRINT);
	return $_POST['tabla'];
}

function post_rest()
{
	$url = "https://gorest.co.in/public/v1/users?access-token=a217ccb49c3be7355cc0c0c12ad4d2e6f915c23094b2e67ed30ed8c092e745de";
	$adatok = array(
		"name" => "zold",
		"email" => "test@proba.hu",
		"gender" => "female",
		"status" => "active"
	);
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($adatok));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$post = curl_exec($ch);
		curl_close($ch);
		echo '<h2>A bejegyzett adatok: ' . $post . '</h2>';
}

function kiir_rest()
{
	$url = "https://gorest.co.in/public/v1/users/3234?access-token=a217ccb49c3be7355cc0c0c12ad4d2e6f915c23094b2e67ed30ed8c092e745de";
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$kiir = curl_exec($ch);
	curl_close($ch);
	echo '<h2>A bejegyzett adatok: ' . $kiir . '</h2>';
}
	
function put_rest()
{
	$url = "https://gorest.co.in/public/v1/users/3234?access-token=a217ccb49c3be7355cc0c0c12ad4d2e6f915c23094b2e67ed30ed8c092e745de";
	$adatok = array("name" => "proba2");
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($adatok));
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$put = curl_exec($ch);
	curl_close($ch);
}

function delete_rest()
{
	$url = "https://gorest.co.in/public/v1/users/3228?access-token=a217ccb49c3be7355cc0c0c12ad4d2e6f915c23094b2e67ed30ed8c092e745de";
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$del = curl_exec($ch);
	curl_close($ch);
	echo '<h2>Az adatok törlődtek!</h2>';
}

if(isset($_POST['lekerdezes'])) { 
	get_rest(); 
	create_table($_POST['tabla']['data']);
}
if(isset($_POST['beiras'])) { 
	post_rest();
	//kiir_rest();
}
if(isset($_POST['atiras'])) { 
	put_rest(); 
	kiir_rest();
}
if(isset($_POST['torles'])) { 
	delete_rest(); 
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
    <body>
        <div class="hatter">
            <div class="uzenet">
    		    <h2>Webszolgáltatás tesztelése</h2>
				<form class="buttons" method="post">
    		    	<input type="submit" name="lekerdezes" value="Lekérdezés" />
					<input type="submit" name="beiras" value="Kiegészítés" />
					<input type="submit" name="atiras" value="Módosítás" />
					<input type="submit" name="torles" value="Törlés" />
				</form>
			</div>
		</div>
	</body>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>	
<br><br>
<br><br>	
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>	
<br><br>
<br><br>	
<br><br>
<br><br>	
<br><br>
<br><br>	
</html>