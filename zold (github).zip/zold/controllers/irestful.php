<?php

class Irestful_Controller
{
	public $baseName = 'irestful';

	public function main(array $vars)
	{
    	$view = new View_Loader($this->baseName."_view");

	}
}

?>