<?php
class Grafikon_Controller
{
	public $baseName = 'grafikon';
	public function main(array $vars)
	{
        $pdfModel = new grafikon_Model;
		$pdfModel->grafikon();	
		$view = new View_Loader($this->baseName."_main");
	}
}
?>