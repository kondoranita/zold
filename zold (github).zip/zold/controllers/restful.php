<?php

class Restful_Controller
{
	public $baseName = 'restful';
	public function main(array $vars)
	{
		$view = new View_Loader($this->baseName."_main");
	}
}

?>

